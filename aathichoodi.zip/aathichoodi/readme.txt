=== Aathichoodi ===
Contributors: gsuryalss
Tags: Tamil, Aathichudi, Aathichoodi, Aathichoodi in German, Aathichoodi in English, daily quotes, quotes, leadership, love, peace, philosophy, daily quote, quote of the day, inspirational, agnostic, atheist, knowledge quotes, Avvaiyar, Tamil Classics, German quotes, Deutsch
Requires at least: 3.0
Tested up to: 4.7.3
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


The Āathichoodi (தமிழ் : ஆத்திசூடி) is a collection of single-line quotations written by Avvaiyar in classical language Tamil during circa 1st and 2nd century CE. This plugin helps to display random Aathichoodi Quotes over the website.


== Description ==

Displays random Aathichoodi quotes over the website.

= Key Features ==
* Simple short code '[aathichoodi]' available to display random quotes.
* Simple drag and drop widget options integrated with wordpress structure.
* Localizations are available in Tamil, English and Deutsch (German).
* Facility to extend and modify the functionality of the plugin using WordPress filters.

== Installation ==

**Follow the steps to install the plugin:**

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly by searching "Aathichoodi" plugin.
2. Activate the plugin through the 'Plugins' screen in WordPress

After installing the plugin, Navigate to Appearance -> Widget and then add the widget "Aathichoodi".
Random Quotes will be displayed in the website as per your widget/Theme settings.
